/**
 * 
 */
/**
 * 
 */
module OnlineShoppingApp {
	requires java.base;
}